namespace RPGKit.FantasyNameGenerator.Generators
{
	public interface INameGenerator
	{
		string GetName();	
	}
}
