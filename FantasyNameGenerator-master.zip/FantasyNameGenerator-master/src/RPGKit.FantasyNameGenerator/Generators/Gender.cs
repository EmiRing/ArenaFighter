namespace RPGKit.FantasyNameGenerator.Generators
{
    public enum Gender
    {
        Male,
        Female
    }
}