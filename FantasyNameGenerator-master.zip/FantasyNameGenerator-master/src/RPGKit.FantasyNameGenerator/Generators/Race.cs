namespace RPGKit.FantasyNameGenerator.Generators
{
	public enum Race
	{
        None=0,
		Goblin=1,
		Orc=2
	}
}

