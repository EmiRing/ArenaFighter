namespace RPGKit.FantasyNameGenerator.Generators
{
	public enum Classes
	{
		None,
		Cleric,
		Rogue,
		Warrior,
		Wizard
	}
}
