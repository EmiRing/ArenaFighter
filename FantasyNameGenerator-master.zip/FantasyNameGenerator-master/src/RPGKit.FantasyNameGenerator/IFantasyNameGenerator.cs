namespace RPGKit.FantasyNameGenerator
{
	public interface IFantasyNameGenerator
	{
		FantasyName[] GetFantasyNames(int numNames);
	}
}
